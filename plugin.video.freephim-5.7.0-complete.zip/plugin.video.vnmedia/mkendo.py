import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'resources', 'lib'))
from codequick import Route, Listitem, run
@Route.register
def root(plugin, content_type='video'):
    streams = [
        ('OPhim', 'https://raw.githubusercontent.com/kenvnm/kvn/main/ophim.png', '/resources/lib/mkd/onphim/ophim:index_ophim'),
        ('KKphim', 'https://raw.githubusercontent.com/kenvnm/kvn/main/kkphim.png', '/resources/lib/mkd/onphim/kkphim:index_kkphim'),
        ('NguonC', 'https://raw.githubusercontent.com/kenvnm/kvn/main/nguonc.png', '/resources/lib/mkd/onphim/nguonc:index_nguonc')
    ]
    for name_key, banner_key, url_key in streams:
        item = Listitem()
        item.label = name_key
        item.info['mediatype'] = 'tvshow'
        item.art['thumb'] = item.art['poster'] = banner_key
        item.set_callback(Route.ref(url_key))
        yield item
if __name__ == '__main__':
    run()
